**********************************************************************
Feature detection
**********************************************************************

.. py:data:: pygit2.features

   This variable contains a combination of `GIT_FEATURE_*` flags,
   indicating which features a particular build of libgit2 supports.
