**********************************************************************
Commit log
**********************************************************************

.. automethod:: pygit2.Repository.walk


.. automethod:: pygit2.Walker.hide
.. automethod:: pygit2.Walker.push
.. automethod:: pygit2.Walker.reset
.. automethod:: pygit2.Walker.sort
.. automethod:: pygit2.Walker.simplify_first_parent
