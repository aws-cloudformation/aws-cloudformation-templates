**********************************************************************
The development version
**********************************************************************

.. image:: https://travis-ci.org/libgit2/pygit2.svg?branch=master
   :target: http://travis-ci.org/libgit2/pygit2

.. code-block:: sh

    $ git clone git://github.com/libgit2/pygit2.git
    $ cd pygit2
    $ python setup.py install
    $ python setup.py test

